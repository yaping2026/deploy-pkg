const fs = require('fs');
const path = require('path');

// ===== 存储模式：github（默认，Railway用）| local（腾讯云国内服务器用）=====
const STORAGE_MODE = (process.env.STORAGE_MODE || 'github').toLowerCase();
const IS_LOCAL = STORAGE_MODE === 'local';

// 本地内容文件目录
const CONTENT_DIR = process.env.CONTENT_DIR || path.join(__dirname, 'content');

// 旧文件CDN回退源（部署前历史文件已镜像到公开仓库 deploy-pkg）
// 本地没有的文件（旧PDF/图片/录音）按需从这里拉取并缓存到本地
const CDN_FALLBACK_BASE = process.env.CDN_FALLBACK_BASE || 'https://gcore.jsdelivr.net/gh/yaping2026/deploy-pkg@main';

const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const GITHUB_REPO = process.env.GITHUB_REPO || 'yaping2026/reading-checkin';
// v5.4: 内容文件写入 data 分支，避免触发 Railway 自动部署
const GITHUB_CONTENT_BRANCH = 'data';

function ensureContentDir() {
  if (!fs.existsSync(CONTENT_DIR)) {
    fs.mkdirSync(CONTENT_DIR, { recursive: true });
  }
}

// 校验文件名安全性（防路径穿越）
function safeFilename(filename) {
  if (!filename || filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
    throw new Error('invalid filename: ' + filename);
  }
  return filename;
}

function githubFetch(url, options = {}) {
  return fetch(url, {
    ...options,
    headers: {
      Authorization: `token ${GITHUB_TOKEN}`,
      Accept: 'application/vnd.github.v3+json',
      'Content-Type': 'application/json',
      'User-Agent': 'reading-checkin',
      ...options.headers
    }
  });
}

async function getCurrentCommit() {
  const refRes = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/ref/heads/${GITHUB_CONTENT_BRANCH}`);
  if (!refRes.ok) throw new Error(`Failed to get ref: ${refRes.status}`);
  const refData = await refRes.json();

  const commitRes = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/commits/${refData.object.sha}`);
  if (!commitRes.ok) throw new Error(`Failed to get commit: ${commitRes.status}`);
  const commitData = await commitRes.json();

  return {
    commitSha: refData.object.sha,
    treeSha: commitData.tree.sha
  };
}

async function createBlobs(files) {
  const results = [];
  for (const { filename, buffer } of files) {
    const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/blobs`, {
      method: 'POST',
      body: JSON.stringify({
        content: buffer.toString('base64'),
        encoding: 'base64'
      })
    });
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Failed to create blob for ${filename}: ${res.status} ${err}`);
    }
    const data = await res.json();
    results.push({ filename, sha: data.sha });
  }
  return results;
}

async function createTree(baseTreeSha, items) {
  const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/trees`, {
    method: 'POST',
    body: JSON.stringify({
      base_tree: baseTreeSha,
      tree: items
    })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Failed to create tree: ${res.status} ${err}`);
  }
  const data = await res.json();
  return data.sha;
}

async function createCommit(treeSha, parentSha, message) {
  const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/commits`, {
    method: 'POST',
    body: JSON.stringify({
      message,
      tree: treeSha,
      parents: [parentSha]
    })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Failed to create commit: ${res.status} ${err}`);
  }
  const data = await res.json();
  return data.sha;
}

async function updateRef(sha) {
  const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/refs/heads/${GITHUB_CONTENT_BRANCH}`, {
    method: 'PATCH',
    body: JSON.stringify({ sha })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Failed to update ref: ${res.status} ${err}`);
  }
}

async function uploadFiles(files) {
  // 本地存储模式：直接写入本地 content/ 目录
  if (IS_LOCAL) {
    ensureContentDir();
    for (const { filename, buffer } of files) {
      fs.writeFileSync(path.join(CONTENT_DIR, safeFilename(filename)), buffer);
    }
    console.log(`[files] 本地模式：已保存 ${files.length} 个内容文件到 ${CONTENT_DIR}`);
    return files.map(f => ({ filename: f.filename, url: getFileUrl(f.filename) }));
  }

  if (!GITHUB_TOKEN) throw new Error('GITHUB_TOKEN not set');

  const blobs = await createBlobs(files);
  const { commitSha, treeSha } = await getCurrentCommit();

  const treeItems = blobs.map(b => ({
    path: `content/${b.filename}`,
    mode: '100644',
    type: 'blob',
    sha: b.sha
  }));

  const newTreeSha = await createTree(treeSha, treeItems);
  const newCommitSha = await createCommit(newTreeSha, commitSha, `Upload ${files.length} reading content files`);
  await updateRef(newCommitSha);

  return blobs.map(b => ({
    filename: b.filename,
    url: `https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_CONTENT_BRANCH}/content/${b.filename}`
  }));
}

async function listFiles() {
  // 本地存储模式：列出本地 content/ 目录
  if (IS_LOCAL) {
    try {
      return fs.readdirSync(CONTENT_DIR).filter(n => !n.startsWith('.'));
    } catch (e) {
      return [];
    }
  }
  if (!GITHUB_TOKEN) return [];
  try {
    const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/contents/content?ref=${GITHUB_CONTENT_BRANCH}`);
    if (res.status === 404) return [];
    if (!res.ok) {
      console.error(`Failed to list files: ${res.status}`);
      return [];
    }
    const data = await res.json();
    return data.map(f => f.name);
  } catch (e) {
    console.error('List files error:', e.message);
    return [];
  }
}

async function deleteFiles(filenames) {
  // 本地存储模式：删除本地文件
  if (IS_LOCAL) {
    for (const f of filenames) {
      try { fs.unlinkSync(path.join(CONTENT_DIR, safeFilename(f))); } catch (e) {}
    }
    return;
  }
  if (!GITHUB_TOKEN) throw new Error('GITHUB_TOKEN not set');
  if (filenames.length === 0) return;

  const { commitSha, treeSha } = await getCurrentCommit();

  const treeItems = filenames.map(f => ({
    path: `content/${f}`,
    mode: '100644',
    type: 'blob',
    sha: null
  }));

  const newTreeSha = await createTree(treeSha, treeItems);
  const newCommitSha = await createCommit(newTreeSha, commitSha, `Delete ${filenames.join(', ')}`);
  await updateRef(newCommitSha);
}

function getFileUrl(filename) {
  const baseUrl = process.env.BASE_URL || '';
  return baseUrl ? `${baseUrl}/content-proxy/${filename}` : `https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_CONTENT_BRANCH}/content/${filename}`;
}

async function getFileBuffer(filename) {
  safeFilename(filename);

  // 本地存储模式：本地优先，未命中则从CDN懒加载历史文件并缓存
  if (IS_LOCAL) {
    const localPath = path.join(CONTENT_DIR, filename);
    if (fs.existsSync(localPath)) {
      return fs.readFileSync(localPath);
    }
    // CDN懒加载：录音在 audio/ 目录，其他内容在 content/ 目录
    const subDir = filename.startsWith('audio_') ? 'audio' : 'content';
    const cdnUrl = `${CDN_FALLBACK_BASE}/${subDir}/${encodeURIComponent(filename)}`;
    try {
      const res = await fetch(cdnUrl, { signal: AbortSignal.timeout(60000) });
      if (res.ok) {
        const arrayBuffer = await res.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        try {
          ensureContentDir();
          fs.writeFileSync(localPath, buffer);
          console.log(`[files] CDN懒加载成功并已缓存: ${filename} (${Math.round(buffer.length / 1024)}KB)`);
        } catch (e) {
          console.error('[files] 缓存写入失败(不影响本次返回):', e.message);
        }
        return buffer;
      }
      throw new Error(`CDN ${res.status}`);
    } catch (e) {
      console.error(`[files] 文件不存在且CDN回退失败: ${filename} (${e.message})`);
      throw new Error('文件不存在: ' + filename);
    }
  }

  if (!GITHUB_TOKEN) throw new Error('GITHUB_TOKEN not set');
  // 使用 raw 模式获取文件（Contents API 有 1MB 限制，PDF经常超1MB会被截断损坏）
  // Accept: application/vnd.github.v3.raw 让 GitHub 直接返回二进制内容，支持最大100MB
  const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/contents/content/${filename}?ref=${GITHUB_CONTENT_BRANCH}`, {
    headers: {
      Accept: 'application/vnd.github.v3.raw'
    }
  });
  if (!res.ok) throw new Error(`Failed to fetch file: ${res.status}`);
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

module.exports = { uploadFiles, listFiles, deleteFiles, getFileUrl, getFileBuffer };
