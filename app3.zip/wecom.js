const axios = require('axios');
const fs = require('fs');
const path = require('path');

async function sendText(webhookUrl, content, mentionedList, mentionedMobileList) {
  mentionedList = mentionedList || [];
  mentionedMobileList = mentionedMobileList || [];
  const msg = {
    msgtype: 'text',
    text: { content: content }
  };
  // mentioned_list: 企微userid列表，用于@到对应成员
  if (mentionedList.length > 0) {
    msg.text.mentioned_list = mentionedList;
  }
  // mentioned_mobile_list: 手机号列表，用于@手机号对应的群成员
  if (mentionedMobileList.length > 0) {
    msg.text.mentioned_mobile_list = mentionedMobileList;
  }
  return axios.post(webhookUrl, msg);
}

async function sendMarkdown(webhookUrl, content) {
  return axios.post(webhookUrl, {
    msgtype: 'markdown',
    markdown: { content: content }
  });
}

async function sendImage(webhookUrl, imagePath) {
  try {
    const imageBuffer = fs.readFileSync(imagePath);
    return sendImageBuffer(webhookUrl, imageBuffer);
  } catch (e) {
    console.error('sendImage error:', e.message);
    throw e;
  }
}

// 直接接收 Buffer 发送图片（scheduler 从 GitHub 获取文件 buffer 后调用）
async function sendImageBuffer(webhookUrl, imageBuffer) {
  try {
    const crypto = require('crypto');
    const base64 = imageBuffer.toString('base64');
    const md5 = crypto.createHash('md5').update(imageBuffer).digest('hex');
    const resp = await axios.post(webhookUrl, {
      msgtype: 'image',
      image: { base64: base64, md5: md5 }
    });
    // v5.5: 检查企微errcode，errcode!=0说明发送失败（如限流45009）
    if (resp.data && resp.data.errcode && resp.data.errcode !== 0) {
      throw new Error('企微返回错误: errcode=' + resp.data.errcode + ' errmsg=' + (resp.data.errmsg || ''));
    }
    return resp;
  } catch (e) {
    console.error('sendImageBuffer error:', e.message);
    throw e;
  }
}

async function sendNews(webhookUrl, title, description, url, picurl) {
  return axios.post(webhookUrl, {
    msgtype: 'news',
    news: {
      articles: [{
        title: title,
        description: description,
        url: url,
        picurl: picurl || ''
      }]
    }
  });
}

// 上传文件到企微获取 media_id
async function uploadFileToWecom(webhookUrl, fileBuffer, filename) {
  try {
    // 从 webhookUrl 提取 key
    const keyMatch = webhookUrl.match(/key=([a-zA-Z0-9_-]+)/);
    if (!keyMatch) throw new Error('无法从webhookUrl提取key');
    const key = keyMatch[1];

    const FormData = require('form-data');
    const form = new FormData();
    form.append('media', fileBuffer, { filename: filename, contentType: 'audio/mpeg' });

    const uploadUrl = `https://qyapi.weixin.qq.com/cgi-bin/webhook/upload_media?key=${key}&type=file`;
    const resp = await axios.post(uploadUrl, form, {
      headers: form.getHeaders(),
      maxBodyLength: 20 * 1024 * 1024
    });
    if (resp.data.errcode !== 0) {
      throw new Error('企微上传失败: ' + (resp.data.errmsg || JSON.stringify(resp.data)));
    }
    return resp.data.media_id;
  } catch (e) {
    console.error('uploadFileToWecom error:', e.message);
    throw e;
  }
}

// 发送文件消息
async function sendFile(webhookUrl, mediaId) {
  const resp = await axios.post(webhookUrl, {
    msgtype: 'file',
    file: { media_id: mediaId }
  });
  // v5.5: 检查企微errcode
  if (resp.data && resp.data.errcode && resp.data.errcode !== 0) {
    throw new Error('企微返回错误: errcode=' + resp.data.errcode + ' errmsg=' + (resp.data.errmsg || ''));
  }
  return resp;
}

// 上传并发送文件（一步到位）
async function uploadAndSendFile(webhookUrl, fileBuffer, filename) {
  const mediaId = await uploadFileToWecom(webhookUrl, fileBuffer, filename);
  return sendFile(webhookUrl, mediaId);
}

module.exports = { sendText, sendMarkdown, sendImage, sendImageBuffer, sendNews, uploadFileToWecom, sendFile, uploadAndSendFile };
