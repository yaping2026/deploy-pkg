/**
 * 海报发送器
 * 负责将打卡海报发送到企微群，并标记 posterSent 状态
 *
 * v5.5 修复（2026-07-30）：
 *  - 增加 60 秒延迟最终重试：7 次即时重试全失败后，等 60 秒再做一次尝试
 *    覆盖容器短暂重启/企微限流恢复场景，只重试一次不会刷屏
 *  - 配合 wecom.js errcode 检查，确保限流等"假成功"被正确识别为失败
 *  v5.3 修复（2026-07-27）：
 *  - 增加 locallySentPosters 本地缓存，防止"发送成功但标记失败"时补偿任务重复发送
 *  - generateAndSendPosterForCheckin 前置检查 posterSent，已发送的直接跳过
 *  - 即时发送重试 5→7 次，退避加长至 3s/5s/8s/12s/16s/20s + 随机抖动
 *  - 导出 claimPoster / setPosterSentFlag 供补偿任务使用
 */

const db = require('./db');
const wecom = require('./wecom');
const poster = require('./poster');

// 进程内"发送中"集合：防止同一进程内并发调用重复进入发送逻辑
const sendingInFlight = new Set();

// 进程内"已发送"集合：记录本进程已成功发送到企微的海报
// 用于"发送成功但GitHub标记失败"时，补偿任务能识别并跳过，避免重复发送（刷屏根因）
const locallySentPosters = new Set();

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function getPosterBaseUrl() {
  return process.env.BASE_URL || process.env.RAILWAY_PUBLIC_URL || 'https://web-production-d6162.up.railway.app';
}

function buildPosterStats(member, today, data) {
  const memberId = member.id;
  const memberCheckins = data.checkins.filter(c => c.memberId === memberId).sort((a, b) => a.date.localeCompare(b.date));
  const currentMonth = today.substring(0, 7);
  const monthStart = currentMonth + '-01';
  const monthEnd = today;

  let monthEligibleDays = 0;
  const d = new Date(monthStart);
  while (d.toISOString().split('T')[0] <= monthEnd) {
    monthEligibleDays++;
    d.setDate(d.getDate() + 1);
  }

  const monthCheckins = memberCheckins.filter(c => c.date >= monthStart && c.date <= monthEnd);
  const monthTotalCheckins = monthCheckins.length;
  const monthMissedDays = Math.max(0, monthEligibleDays - monthTotalCheckins);
  const makeupUsed = monthCheckins.filter(c => c.type === 'makeup' || c.type === 'makeup-read' || c.type === 'makeup-checkin').length;
  const remainingMakeup = Math.max(0, 2 - makeupUsed);
  const consecutiveDays = memberCheckins.length;

  return { monthEligibleDays, monthTotalCheckins, monthMissedDays, remainingMakeup, consecutiveDays };
}

// 可靠地把 posterSent 设为指定值（带 SHA 重试 + 读回验证，最多15次，指数退避）
async function setPosterSentFlag(checkinId, value) {
  for (let i = 0; i < 15; i++) {
    try {
      const fresh = await db.readFresh();
      const c = fresh.data.checkins.find(x => x.id === checkinId);
      if (!c) return false;
      if (c.posterSent === value) return true; // 已是目标值，幂等
      c.posterSent = value;
      await db.writeWithData(fresh.data, fresh.sha);
      // 读回验证是否真正持久化
      const v = await db.readFresh();
      const vc = v.data.checkins.find(x => x.id === checkinId);
      if (vc && vc.posterSent === value) return true;
    } catch (e) {
      if (e && e.message && e.message.includes('SHA') && i < 14) {
        await sleep(150 * (i + 1));
        continue;
      }
      console.error('[poster] setPosterSent 失败 id=' + checkinId + ' value=' + value + ':', e.message);
      return false;
    }
    await sleep(150 * (i + 1));
  }
  return false;
}

// 原子认领发送权：若尚未发送则标记 true 并返回 ok；若已被认领(其他路径/实例已发)返回 alreadySent
// 利用 GitHub SHA 乐观锁实现「读-判断-写」原子：第一个成功写入 posterSent=true 的调用获得发送权，
// 其余调用在 SHA 冲突后重读会发现 posterSent 已为 true → 放弃发送。
async function claimPoster(checkinId) {
  for (let i = 0; i < 15; i++) {
    try {
      const fresh = await db.readFresh();
      const c = fresh.data.checkins.find(x => x.id === checkinId);
      if (!c) return { ok: false, reason: 'notfound' };
      if (c.posterSent) return { ok: false, alreadySent: true };
      c.posterSent = true;
      try {
        await db.writeWithData(fresh.data, fresh.sha);
        return { ok: true };
      } catch (e) {
        if (e && e.message && e.message.includes('SHA') && i < 14) {
          await sleep(150 * (i + 1));
          continue;
        }
        return { ok: false, error: e.message };
      }
    } catch (e) {
      if (e && e.message && e.message.includes('SHA') && i < 14) {
        await sleep(150 * (i + 1));
        continue;
      }
      console.error('[poster] claim 失败 id=' + checkinId + ':', e.message);
      return { ok: false, error: e.message };
    }
  }
  return { ok: false, error: 'max-retry' };
}

async function generateAndSendPosterForCheckin(checkinId, providedData, providedPosterBuffer) {
  // ① 进程内快速防重：同一打卡正在发送中，直接跳过
  if (sendingInFlight.has(checkinId)) {
    return { alreadySent: true, skipped: 'in-flight' };
  }
  sendingInFlight.add(checkinId);

  try {
    // ①.5 本地缓存检查：本进程已成功发送过，跳过并修复标记
    if (locallySentPosters.has(checkinId)) {
      console.log('[poster] 本进程已发送过，跳过 checkinId=' + checkinId);
      await setPosterSentFlag(checkinId, true);
      return { alreadySent: true, skipped: 'local-cache' };
    }

    // ② 直接进入发送流程（不先写GitHub标记，避免高并发时SHA冲突阻塞发送）
    let data = providedData;
    if (!data) {
      const fresh = await db.readFresh();
      data = fresh.data;
    }
    const checkin = data.checkins.find(c => c.id === checkinId);
    if (!checkin) throw new Error('打卡记录不存在');

    // ②.5 前置检查：posterSent 已为 true，说明已被其他路径发送，直接跳过
    if (checkin.posterSent) {
      console.log('[poster] posterSent已为true，跳过 checkinId=' + checkinId);
      return { alreadySent: true, skipped: 'already-marked' };
    }

    const member = data.members.find(m => m.id === checkin.memberId);
    if (!member) throw new Error('成员不存在');
    const group = data.groups.find(g => g.id === checkin.groupId);
    if (!group || !group.webhookUrl) throw new Error('群组未配置');

    let posterBuffer = providedPosterBuffer;
    if (!posterBuffer) {
      const baseUrl = getPosterBaseUrl();
      const stats = buildPosterStats(member, checkin.date, data);
      posterBuffer = await poster.generatePoster({
        memberName: member.name,
        isMakeup: checkin.type === 'makeup',
        makeupDateStr: checkin.type === 'makeup' ? checkin.date : '',
        stats,
        checkinId: checkin.id,
        baseUrl,
        audioDuration: checkin.audioDuration || 0
      });
    }

    // ③ 发送海报到企微群（带重试，最多7次，退避 3s/5s/8s/12s/16s/20s + 随机抖动）
    // v5.3: 从5次增加到7次，退避时间大幅加长+抖动，应对早高峰企微API限流
    let sendOk = false;
    let lastSendError = null;
    const retryDelays = [3000, 5000, 8000, 12000, 16000, 20000];
    for (let sendRetry = 0; sendRetry < 7; sendRetry++) {
      try {
        if (posterBuffer.length <= 2 * 1024 * 1024) {
          await wecom.sendImageBuffer(group.webhookUrl, posterBuffer);
        } else {
          const filename = member.name + '_' + checkin.date + '_打卡海报.png';
          await wecom.uploadAndSendFile(group.webhookUrl, posterBuffer, filename);
        }
        sendOk = true;
        break;
      } catch (err) {
        lastSendError = err;
        console.error('[poster] 发送尝试 ' + (sendRetry + 1) + '/7 失败:', err.message);
        if (sendRetry < 6) {
          const jitter = Math.floor(Math.random() * 1000);
          await new Promise(r => setTimeout(r, retryDelays[sendRetry] + jitter));
        }
      }
    }

    if (!sendOk) {
      // v5.5: 7次即时重试全失败，60秒后做最后一次尝试
      // 覆盖容器短暂重启、企微限流恢复等场景，只重试一次不会刷屏
      console.log('[poster] 7次重试全失败，60秒后最后尝试 checkinId=' + checkinId + ' name=' + member.name);
      await sleep(60000);
      try {
        if (posterBuffer.length <= 2 * 1024 * 1024) {
          await wecom.sendImageBuffer(group.webhookUrl, posterBuffer);
        } else {
          const filename = member.name + '_' + checkin.date + '_打卡海报.png';
          await wecom.uploadAndSendFile(group.webhookUrl, posterBuffer, filename);
        }
        sendOk = true;
        console.log('[poster] 60秒延迟重试成功 checkinId=' + checkinId + ' name=' + member.name);
      } catch (err) {
        lastSendError = err;
        console.error('[poster] 60秒延迟重试也失败 checkinId=' + checkinId + ':', err.message);
      }
    }

    if (!sendOk) {
      // 发送失败：posterSent 保持 false，交给补偿任务重试
      try {
        await db.addLog('poster-send', 'failed',
          member.name + ' ' + checkin.date + ' 群:' + group.name +
          ' 失败:' + (lastSendError ? lastSendError.message : 'unknown') +
          ' size:' + (posterBuffer.length / 1024).toFixed(1) + 'KB');
      } catch (e) { /* 忽略日志写入失败 */ }
      throw new Error('海报发送失败(' + (lastSendError ? lastSendError.message : 'unknown') + ')');
    }

    // 发送成功：先记入本地缓存（防补偿任务重复发），再标记 GitHub
    locallySentPosters.add(checkinId);
    await setPosterSentFlag(checkinId, true);
    console.log('[poster] 海报发送成功:', member.name, group.name, '(' + (posterBuffer.length / 1024).toFixed(1) + 'KB)');
    return { ok: true, size: posterBuffer.length };
  } finally {
    // 无论成功/失败，都释放进程内发送锁
    sendingInFlight.delete(checkinId);
  }
}

// 手动补发接口使用：可靠标记 posterSent=true（认领发送权，防补偿任务重复发）
async function markPosterSent(checkinId) {
  return setPosterSentFlag(checkinId, true);
}

module.exports = { getPosterBaseUrl, buildPosterStats, generateAndSendPosterForCheckin, markPosterSent, claimPoster, setPosterSentFlag };
