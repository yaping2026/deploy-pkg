/**
 * 后端海报生成模块
 * 使用 @napi-rs/canvas 在服务器端生成打卡海报
 * 逻辑与前端 checkin.html 的 generateAndShowPoster 一致
 */

const { createCanvas, GlobalFonts } = require('@napi-rs/canvas');
const QRCode = require('qrcode');
const path = require('path');

// 注册中文字体（Noto Sans SC），确保海报中文能正常显示
(function registerFonts() {
  try {
    const regular = path.join(__dirname, 'node_modules/@fontsource/noto-sans-sc/files/noto-sans-sc-chinese-simplified-400-normal.woff2');
    const bold = path.join(__dirname, 'node_modules/@fontsource/noto-sans-sc/files/noto-sans-sc-chinese-simplified-700-normal.woff2');
    GlobalFonts.registerFromPath(regular, 'NotoSansSC');
    GlobalFonts.registerFromPath(bold, 'NotoSansSC-Bold');
  } catch (e) {
    console.error('[poster] 字体注册失败:', e.message);
  }
})();
/**
 * 生成打卡海报图片 Buffer
 * @param {Object} params
 * @param {string} params.memberName - 成员姓名
 * @param {boolean} params.isMakeup - 是否补打卡
 * @param {string} params.makeupDateStr - 补打卡日期字符串
 * @param {Object} params.stats - 统计数据
 * @param {number} params.stats.monthEligibleDays - 本月天数
 * @param {number} params.stats.monthTotalCheckins - 累计打卡
 * @param {number} params.stats.monthMissedDays - 未打卡
 * @param {number} params.stats.remainingMakeup - 剩余补卡
 * @param {number} params.stats.consecutiveDays - 连续打卡天数
 * @param {number} params.checkinId - 打卡记录ID（用于二维码）
 * @param {string} params.baseUrl - 站点根URL（用于二维码链接）
 * @param {number} params.audioDuration - 录音时长（秒）
 * @returns {Promise<Buffer>} PNG图片Buffer
 */
async function generatePoster(params) {
  const {
    memberName,
    isMakeup,
    makeupDateStr,
    stats,
    checkinId,
    baseUrl,
    audioDuration
  } = params;

  const W = 720, H = 1080;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  // 背景渐变
  const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
  bgGrad.addColorStop(0, '#1a237e');
  bgGrad.addColorStop(0.5, '#283593');
  bgGrad.addColorStop(1, '#1565C0');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  // 装饰圆
  ctx.globalAlpha = 0.08;
  ctx.fillStyle = '#fff';
  ctx.beginPath(); ctx.arc(600, 150, 200, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(100, 900, 150, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;

  // 所有文字居中
  ctx.textAlign = 'center';

  // 标题
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 36px NotoSansSC-Bold';
  const posterTitle = isMakeup ? '正品堂 《京瓷哲学》补打卡' : '正品堂 《京瓷哲学》共读打卡';
  ctx.fillText(posterTitle, W / 2, 100);

  // 日期（使用北京时间，避免UTC导致凌晨跨日错误）
  const now = new Date();
  const tzParts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric', month: 'numeric', day: 'numeric', weekday: 'short'
  }).formatToParts(now);
  const _y = tzParts.find(p => p.type === 'year').value;
  const _m = tzParts.find(p => p.type === 'month').value;
  const _d = tzParts.find(p => p.type === 'day').value;
  const _wd = tzParts.find(p => p.type === 'weekday').value;
  const weekDayMap = { 'Sun': '日', 'Mon': '一', 'Tue': '二', 'Wed': '三', 'Thu': '四', 'Fri': '五', 'Sat': '六' };
  const dateStr = _y + '年' + parseInt(_m) + '月' + parseInt(_d) + '日';
  const weekday = '星期' + weekDayMap[_wd];
  ctx.font = '22px NotoSansSC';
  ctx.fillStyle = 'rgba(255,255,255,0.7)';
  if (isMakeup && makeupDateStr) {
    ctx.fillText('补打卡日期：' + makeupDateStr, W / 2, 140);
  } else {
    ctx.fillText(dateStr + ' ' + weekday, W / 2, 140);
  }

  // 分隔线
  ctx.strokeStyle = 'rgba(255,255,255,0.2)';
  ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(100, 170); ctx.lineTo(W - 100, 170); ctx.stroke();

  // 用户名
  ctx.fillStyle = '#FFC107';
  ctx.font = 'bold 44px NotoSansSC-Bold';
  ctx.fillText(memberName || '未知', W / 2, 240);

  // 核心数据卡片区域
  const cardY = 280;
  const cardH = 280;
  const cardX = 60;
  const cardW = W - 120;

  // 半透明白色卡片背景
  ctx.fillStyle = 'rgba(255,255,255,0.12)';
  roundRect(ctx, cardX, cardY, cardW, cardH, 20);
  ctx.fill();

  // 4个数据项
  const items = [
    { num: stats.monthEligibleDays, label: '本月天数', color: '#4CAF50' },
    { num: stats.monthTotalCheckins, label: '累计打卡', color: '#42A5F5' },
    { num: stats.monthMissedDays, label: '未打卡', color: '#EF5350' },
    { num: stats.remainingMakeup, label: '剩余补卡', color: '#FF9800' }
  ];

  const itemW = cardW / 4;
  for (let i = 0; i < items.length; i++) {
    const cx = cardX + itemW * i + itemW / 2;
    const cy = cardY + 80;

    // 数字
    ctx.fillStyle = items[i].color;
    ctx.font = 'bold 52px NotoSansSC-Bold';
    ctx.fillText(String(items[i].num), cx, cy);

    // 标签
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.font = '18px NotoSansSC';
    ctx.fillText(items[i].label, cx, cy + 35);

    // 分隔线（除了最后一个）
    if (i < items.length - 1) {
      ctx.strokeStyle = 'rgba(255,255,255,0.15)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(cardX + itemW * (i + 1), cardY + 40);
      ctx.lineTo(cardX + itemW * (i + 1), cardY + cardH - 40);
      ctx.stroke();
    }
  }

  // 365天连续打卡进度条
  if (stats.consecutiveDays > 0) {
    const barY = cardY + cardH - 70;
    const barW = cardW - 60;
    const barX = cardX + 30;
    const pct = Math.min(1, stats.consecutiveDays / 365);

    ctx.fillStyle = 'rgba(255,255,255,0.15)';
    roundRect(ctx, barX, barY, barW, 16, 8);
    ctx.fill();

    const grad = ctx.createLinearGradient(barX, 0, barX + barW * pct, 0);
    grad.addColorStop(0, '#FF9800');
    grad.addColorStop(1, '#FFC107');
    ctx.fillStyle = grad;
    roundRect(ctx, barX, barY, barW * pct, 16, 8);
    ctx.fill();

    ctx.fillStyle = '#FFC107';
    ctx.font = 'bold 18px NotoSansSC-Bold';
    ctx.fillText('🏅 连续365天打卡奖励 ' + stats.consecutiveDays + '/365', W / 2, barY - 10);
  }

  // 励志标语
  const slogans = [
    '提升心性，磨炼灵魂',
    '坚持每日精进',
    '读书百遍，其义自见',
    '日拱一卒，功不唐捐',
    '学而不思则罔，思而不学则殆'
  ];
  const slogan = slogans[Math.floor(Math.random() * slogans.length)];

  ctx.fillStyle = '#fff';
  ctx.font = '24px NotoSansSC';
  ctx.fillText('"' + slogan + '"', W / 2, 650);

  // 底部
  ctx.fillStyle = 'rgba(255,255,255,0.4)';
  ctx.font = '16px NotoSansSC';
  ctx.fillText('坚持读书，遇见更好的自己', W / 2, 710);

  // 二维码区域
  try {
    let qrContent = '';
    let qrLabel = '';
    if (checkinId) {
      qrContent = baseUrl + '/listen?id=' + checkinId;
      qrLabel = '扫码验证读书录音';
    } else {
      qrContent = baseUrl + '/checkin.html';
      qrLabel = '扫码加入共读';
    }

    const qr = QRCode.create(qrContent, { errorCorrectionLevel: 'M' });
    const moduleCount = qr.modules.size;
    const qrSize = 150;
    const qrX = W / 2 - qrSize / 2;
    const qrY = 740;
    const cellSize = qrSize / moduleCount;

    // 白色圆角背景
    ctx.fillStyle = '#fff';
    roundRect(ctx, qrX - 12, qrY - 12, qrSize + 24, qrSize + 70, 12);
    ctx.fill();

    // 绘制二维码像素
    for (let row = 0; row < moduleCount; row++) {
      for (let col = 0; col < moduleCount; col++) {
        if (qr.modules.get(row, col)) {
          ctx.fillStyle = '#1a237e';
          ctx.fillRect(qrX + col * cellSize, qrY + row * cellSize, cellSize + 0.5, cellSize + 0.5);
        }
      }
    }

    // 二维码下方文字
    ctx.fillStyle = '#1a237e';
    ctx.font = '12px NotoSansSC';
    ctx.textAlign = 'center';
    ctx.fillText(qrLabel, W / 2, qrY + qrSize + 18);

    // 录音时长
    if (audioDuration > 0) {
      const min = String(Math.floor(audioDuration / 60)).padStart(2, '0');
      const sec = String(audioDuration % 60).padStart(2, '0');
      ctx.fillStyle = '#666';
      ctx.font = '11px NotoSansSC';
      ctx.fillText('录音时长 ' + min + ':' + sec, W / 2, qrY + qrSize + 32);
    }
  } catch (e) {
    console.error('[poster] 二维码生成失败:', e.message);
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.font = '16px NotoSansSC';
    ctx.textAlign = 'center';
    ctx.fillText('扫码加入共读', W / 2, 870);
  }

  // 底部品牌
  ctx.fillStyle = 'rgba(255,255,255,0.3)';
  ctx.font = '13px NotoSansSC';
  ctx.fillText('正品堂读书打卡系统', W / 2, H - 30);

  // 转为PNG Buffer
  return canvas.toBuffer('image/png');
}

/**
 * 圆角矩形辅助函数（与前端一致）
 */
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

module.exports = { generatePoster };
