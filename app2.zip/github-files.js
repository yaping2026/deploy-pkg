const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const GITHUB_REPO = process.env.GITHUB_REPO || 'yaping2026/reading-checkin';
// v5.4: 内容文件写入 data 分支，避免触发 Railway 自动部署
const GITHUB_CONTENT_BRANCH = 'data';

function githubFetch(url, options = {}) {
  return fetch(url, {
    ...options,
    headers: {
      Authorization: `token ${GITHUB_TOKEN}`,
      Accept: 'application/vnd.github.v3+json',
      'Content-Type': 'application/json',
      'User-Agent': 'reading-checkin',
      ...options.headers
    }
  });
}

async function getCurrentCommit() {
  const refRes = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/ref/heads/${GITHUB_CONTENT_BRANCH}`);
  if (!refRes.ok) throw new Error(`Failed to get ref: ${refRes.status}`);
  const refData = await refRes.json();

  const commitRes = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/commits/${refData.object.sha}`);
  if (!commitRes.ok) throw new Error(`Failed to get commit: ${commitRes.status}`);
  const commitData = await commitRes.json();

  return {
    commitSha: refData.object.sha,
    treeSha: commitData.tree.sha
  };
}

async function createBlobs(files) {
  const results = [];
  for (const { filename, buffer } of files) {
    const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/blobs`, {
      method: 'POST',
      body: JSON.stringify({
        content: buffer.toString('base64'),
        encoding: 'base64'
      })
    });
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Failed to create blob for ${filename}: ${res.status} ${err}`);
    }
    const data = await res.json();
    results.push({ filename, sha: data.sha });
  }
  return results;
}

async function createTree(baseTreeSha, items) {
  const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/trees`, {
    method: 'POST',
    body: JSON.stringify({
      base_tree: baseTreeSha,
      tree: items
    })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Failed to create tree: ${res.status} ${err}`);
  }
  const data = await res.json();
  return data.sha;
}

async function createCommit(treeSha, parentSha, message) {
  const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/commits`, {
    method: 'POST',
    body: JSON.stringify({
      message,
      tree: treeSha,
      parents: [parentSha]
    })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Failed to create commit: ${res.status} ${err}`);
  }
  const data = await res.json();
  return data.sha;
}

async function updateRef(sha) {
  const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/git/refs/heads/${GITHUB_CONTENT_BRANCH}`, {
    method: 'PATCH',
    body: JSON.stringify({ sha })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Failed to update ref: ${res.status} ${err}`);
  }
}

async function uploadFiles(files) {
  if (!GITHUB_TOKEN) throw new Error('GITHUB_TOKEN not set');

  const blobs = await createBlobs(files);
  const { commitSha, treeSha } = await getCurrentCommit();

  const treeItems = blobs.map(b => ({
    path: `content/${b.filename}`,
    mode: '100644',
    type: 'blob',
    sha: b.sha
  }));

  const newTreeSha = await createTree(treeSha, treeItems);
  const newCommitSha = await createCommit(newTreeSha, commitSha, `Upload ${files.length} reading content files`);
  await updateRef(newCommitSha);

  return blobs.map(b => ({
    filename: b.filename,
    url: `https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_CONTENT_BRANCH}/content/${b.filename}`
  }));
}

async function listFiles() {
  if (!GITHUB_TOKEN) return [];
  try {
    const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/contents/content?ref=${GITHUB_CONTENT_BRANCH}`);
    if (res.status === 404) return [];
    if (!res.ok) {
      console.error(`Failed to list files: ${res.status}`);
      return [];
    }
    const data = await res.json();
    return data.map(f => f.name);
  } catch (e) {
    console.error('List files error:', e.message);
    return [];
  }
}

async function deleteFiles(filenames) {
  if (!GITHUB_TOKEN) throw new Error('GITHUB_TOKEN not set');
  if (filenames.length === 0) return;

  const { commitSha, treeSha } = await getCurrentCommit();

  const treeItems = filenames.map(f => ({
    path: `content/${f}`,
    mode: '100644',
    type: 'blob',
    sha: null
  }));

  const newTreeSha = await createTree(treeSha, treeItems);
  const newCommitSha = await createCommit(newTreeSha, commitSha, `Delete ${filenames.join(', ')}`);
  await updateRef(newCommitSha);
}

function getFileUrl(filename) {
  const baseUrl = process.env.BASE_URL || '';
  return baseUrl ? `${baseUrl}/content-proxy/${filename}` : `https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_CONTENT_BRANCH}/content/${filename}`;
}

async function getFileBuffer(filename) {
  if (!GITHUB_TOKEN) throw new Error('GITHUB_TOKEN not set');
  // 使用 raw 模式获取文件（Contents API 有 1MB 限制，PDF经常超1MB会被截断损坏）
  // Accept: application/vnd.github.v3.raw 让 GitHub 直接返回二进制内容，支持最大100MB
  const res = await githubFetch(`https://api.github.com/repos/${GITHUB_REPO}/contents/content/${filename}?ref=${GITHUB_CONTENT_BRANCH}`, {
    headers: {
      Accept: 'application/vnd.github.v3.raw'
    }
  });
  if (!res.ok) throw new Error(`Failed to fetch file: ${res.status}`);
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

module.exports = { uploadFiles, listFiles, deleteFiles, getFileUrl, getFileBuffer };
