const fs = require('fs');
const path = require('path');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'reading-checkin-data.json');

// GitHub persistent storage config
const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const GITHUB_REPO = process.env.GITHUB_REPO || 'yaping2026/reading-checkin';
const GITHUB_DATA_PATH = 'data/reading-checkin-data.json';
// v5.4: 数据写入 data 分支，避免触发 Railway 自动部署（main 分支只放代码）
const GITHUB_DATA_BRANCH = 'data';

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DEFAULT_DATA = {
  groups: [],
  members: [],
  checkins: [],
  nextGroupId: 1,
  nextMemberId: 1,
  nextCheckinId: 1
};

// 缓存 GitHub SHA，避免每次写入都要先读取
let cachedSha = null;

async function readFromGitHub() {
  if (!GITHUB_TOKEN) return null;
  try {
    const url = `https://api.github.com/repos/${GITHUB_REPO}/contents/${GITHUB_DATA_PATH}?ref=${GITHUB_DATA_BRANCH}`;
    const res = await fetch(url, {
      headers: {
        Authorization: `token ${GITHUB_TOKEN}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'reading-checkin'
      }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw new Error(`GitHub read error: ${res.status}`);
    const json = await res.json();
    // 缓存 SHA
    cachedSha = json.sha;

    // 【关键修复】文件超过1MB时，Contents API 返回空 content（encoding="none"）
    // 此时需要用 Git Blobs API 获取完整内容（支持最大100MB）
    let content;
    if (json.content && json.content.length > 0) {
      content = Buffer.from(json.content, 'base64').toString('utf8');
    } else {
      console.log('[db] 数据文件超过1MB，Contents API返回空内容，使用 Git Blobs API 获取...');
      const blobUrl = `https://api.github.com/repos/${GITHUB_REPO}/git/blobs/${json.sha}`;
      const blobRes = await fetch(blobUrl, {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: 'application/vnd.github.v3+json',
          'User-Agent': 'reading-checkin'
        }
      });
      if (!blobRes.ok) throw new Error(`GitHub blob read error: ${blobRes.status}`);
      const blobJson = await blobRes.json();
      content = Buffer.from(blobJson.content, 'base64').toString('utf8');
    }

    return { data: JSON.parse(content), sha: json.sha };
  } catch (e) {
    console.error('GitHub read failed:', e.message);
    return null;
  }
}

async function writeToGitHub(data, sha) {
  if (!GITHUB_TOKEN) return false;
  try {
    const url = `https://api.github.com/repos/${GITHUB_REPO}/contents/${GITHUB_DATA_PATH}`;
    const content = Buffer.from(JSON.stringify(data)).toString('base64');
    const body = {
      message: 'update reading-checkin data',
      content,
      branch: GITHUB_DATA_BRANCH
    };
    if (sha) body.sha = sha;
    const res = await fetch(url, {
      method: 'PUT',
      headers: {
        Authorization: `token ${GITHUB_TOKEN}`,
        Accept: 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
        'User-Agent': 'reading-checkin'
      },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`GitHub write error: ${res.status} ${err}`);
    }
    const json = await res.json();
    // 更新 SHA 缓存
    cachedSha = json.content ? json.content.sha : null;
    return true;
  } catch (e) {
    console.error('GitHub write failed:', e.message);
    return false;
  }
}

// 内存缓存（减少GitHub读取次数）
let memoryCache = null;
let cacheExpiry = 0;
const CACHE_TTL = 30000; // 30秒缓存

// 立即更新内存缓存（同步，不阻塞事件循环）
function updateCache(data) {
  memoryCache = data;
  cacheExpiry = Date.now() + CACHE_TTL;
}

async function read() {
  // 优先使用内存缓存
  if (memoryCache && Date.now() < cacheExpiry) {
    return JSON.parse(JSON.stringify(memoryCache));
  }

  // Try local file first (instant)
  if (fs.existsSync(DB_PATH)) {
    const localData = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    memoryCache = localData;
    cacheExpiry = Date.now() + CACHE_TTL;
    return JSON.parse(JSON.stringify(localData));
  }

  // Try GitHub if no local file
  if (GITHUB_TOKEN) {
    const gh = await readFromGitHub();
    if (gh && gh.data) {
      fs.writeFileSync(DB_PATH, JSON.stringify(gh.data, null, 2), 'utf8');
      memoryCache = gh.data;
      cacheExpiry = Date.now() + CACHE_TTL;
      return JSON.parse(JSON.stringify(gh.data));
    }
  }

  // No data anywhere - create default
  const data = JSON.parse(JSON.stringify(DEFAULT_DATA));
  updateCache(data);
  await persistToFile(data);
  return data;
}

// 强制从GitHub读取最新数据（绕过内存缓存和本地文件）
// 返回 { data, sha } —— sha必须传递给writeWithData使用，确保读写版本一致
// 用于后台修改等写操作，避免多实例本地文件不一致导致覆盖其他实例的修改
async function readFresh() {
  // 始终优先从GitHub读取（多实例间唯一的数据源）
  if (GITHUB_TOKEN) {
    const gh = await readFromGitHub();
    if (gh && gh.data) {
      fs.writeFileSync(DB_PATH, JSON.stringify(gh.data, null, 2), 'utf8');
      memoryCache = gh.data;
      cacheExpiry = Date.now() + CACHE_TTL;
      return { data: JSON.parse(JSON.stringify(gh.data)), sha: gh.sha, fresh: true };
    }
  }

  // Fallback: 本地文件（GitHub不可用时）—— fresh=false 标记，让调用方知道这是旧数据
  if (fs.existsSync(DB_PATH)) {
    const localData = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    memoryCache = localData;
    cacheExpiry = Date.now() + CACHE_TTL;
    return { data: JSON.parse(JSON.stringify(localData)), sha: cachedSha || null, fresh: false };
  }

  // No data anywhere - create default
  const data = JSON.parse(JSON.stringify(DEFAULT_DATA));
  updateCache(data);
  await persistToFile(data);
  return { data, sha: cachedSha || null, fresh: false };
}

// 将数据持久化到本地文件和GitHub
// 关键改进：每次写入前都重新从GitHub读取最新SHA，避免全局cachedSha被并发请求污染
// 同时用写锁保证同一时间只有一个写入操作在进行
let writeLock = Promise.resolve(); // 写锁：链式Promise，所有写入排队执行
async function persistToFile(data) {
  // 本地文件写入
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const jsonStr = JSON.stringify(data, null, 2);
    await fs.promises.writeFile(DB_PATH, jsonStr, 'utf8');
  } catch (e) {
    console.error('[db] local write error:', e.message);
    throw e;
  }

  // GitHub写入：先读最新SHA再写（兼容旧的write()调用方式）
  if (GITHUB_TOKEN) {
    const gh = await readFromGitHub();
    const latestSha = gh ? gh.sha : null;
    const success = await writeToGitHub(data, latestSha);
    if (!success) {
      throw new Error('SHA_CONFLICT: GitHub数据已被其他实例更新，请重新操作');
    }
  }
}

// 【核心修复】使用指定的SHA写入，不再内部重新读取SHA
// 解决问题：persistToFile内部readFromGitHub获取到的SHA可能与数据版本不匹配，
// 导致"用旧数据+新SHA"写入成功但覆盖了其他实例的变更
async function persistToFileWithSha(data, knownSha) {
  // 本地文件写入
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const jsonStr = JSON.stringify(data, null, 2);
    await fs.promises.writeFile(DB_PATH, jsonStr, 'utf8');
  } catch (e) {
    console.error('[db] local write error:', e.message);
    throw e;
  }

  // GitHub写入：使用读取时获取的精确SHA，确保读写版本一致
  if (GITHUB_TOKEN) {
    const useSha = knownSha || cachedSha || null;
    const success = await writeToGitHub(data, useSha);
    if (!success) {
      throw new Error('SHA_CONFLICT: GitHub数据已被其他实例更新（sha=' + (useSha || 'null') + '），请重试');
    }
  }
}

// 写入数据（兼容旧调用方式：await db.write(data)）
// 1. 立即更新内存缓存（同步，确保后续读取一致）
// 2. 异步写入本地文件和GitHub（不阻塞响应，但必须经过写锁排队）
async function write(data) {
  updateCache(data);
  // 所有写入必须经过writeLock，防止与writeWithData并发冲突
  writeLock = writeLock.then(() => persistToFile(data).catch(e => {
    console.error('[db] persist error:', e.message);
  }));
}

// 同步写入（等待 GitHub 写完才返回）
// 使用写锁串行化所有写入操作，防止并发写入导致数据覆盖
async function writeAndWait(data) {
  updateCache(data);
  // 前一次写入若失败，先 recover 避免链式 promise 永久 rejection
  writeLock = writeLock.catch(() => {}).then(() => persistToFile(data));
  await writeLock;
}

async function writeWithData(data, knownSha) {
  updateCache(data);
  // 前一次写入若失败，先 recover 避免链式 promise 永久 rejection
  writeLock = writeLock.catch(() => {}).then(() => persistToFileWithSha(data, knownSha));
  await writeLock;
}

// ========= 定时任务原子锁：检查+标记一步完成 =========
// 原理：readFresh()读最新数据(带SHA) → 检查_cronSent → 标记 → writeWithData()写入(带SHA)
//       写入成功=获取锁；写入失败(409)=其他实例已获取，自动重试
// 返回: true=可以发送, false=今日已发送或失败(跳过)
// =============================================================
async function tryAcquireCronLock(key, today) {
  for (let retry = 0; retry < 5; retry++) {
    const fresh = await readFresh();
    if (!fresh || !fresh.data) {
      console.error('[db] tryAcquireCronLock: readFresh失败');
      return false;
    }
    // 数据非新鲜（GitHub不可用，回退了本地文件），不能用旧数据做原子锁判断
    // 等待1秒后重试，等GitHub恢复
    if (fresh.fresh === false) {
      console.error('[db] tryAcquireCronLock: 数据非新鲜(GitHub不可用)，第' + (retry + 1) + '次重试...');
      await new Promise(r => setTimeout(r, 1000));
      continue;
    }
    // 检查今日是否已发送
    if (fresh.data._cronSent && fresh.data._cronSent[key] === today) {
      return false; // 今日已发送，跳过
    }
    // 标记今日已发送
    if (!fresh.data._cronSent) fresh.data._cronSent = {};
    fresh.data._cronSent[key] = today;
    // 带SHA写入（原子操作）
    try {
      await writeWithData(fresh.data, fresh.sha);
      return true; // 写入成功，获取锁成功
    } catch (e) {
      if (e.message && e.message.includes('SHA')) {
        // SHA冲突，等待500ms后重试
        await new Promise(r => setTimeout(r, 500));
        continue;
      }
      console.error('[db] tryAcquireCronLock: write failed:', e.message);
      return false;
    }
  }
  return false; // 重试5次仍失败，保守跳过
}

// ========= 分布式锁（独立锁文件，不干扰主数据库） =========
// 锁文件存储在 GitHub 的 _locks/ 目录下
// 利用 GitHub API 的 SHA 机制实现原子操作
// =============================================================

// 获取分布式锁（原子操作）
// lockName: 锁名称（如 'morning-send', 'evening-send'）
// ttlSeconds: 锁的过期时间（秒），默认3600秒（1小时）
// 返回: true=获取锁成功, false=获取锁失败
async function acquireDistributedLock(lockName, ttlSeconds) {
  ttlSeconds = ttlSeconds || 3600;
  const lockPath = `_locks/${lockName}.json`;
  const url = `https://api.github.com/repos/${GITHUB_REPO}/contents/${lockPath}?ref=${GITHUB_DATA_BRANCH}`;
  const now = Date.now();

  try {
    // 1. 读取锁文件（获取SHA和内容）
    const res = await fetch(url, {
      headers: {
        Authorization: `token ${GITHUB_TOKEN}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'reading-checkin'
      }
    });

    if (res.status === 404) {
      // 锁文件不存在，创建它（获取锁）
      const lockData = {
        locked: true,
        lockedAt: new Date(now).toISOString(),
        instanceId: process.env.RAILWAY_REPLICA_ID || process.pid || 'unknown',
        ttl: ttlSeconds
      };
      const content = Buffer.from(JSON.stringify(lockData, null, 2)).toString('base64');
      const createRes = await fetch(`https://api.github.com/repos/${GITHUB_REPO}/contents/${lockPath}`, {
        method: 'PUT',
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: 'application/vnd.github.v3+json',
          'Content-Type': 'application/json',
          'User-Agent': 'reading-checkin'
        },
        body: JSON.stringify({
          message: `Acquire lock: ${lockName}`,
          content,
          branch: GITHUB_DATA_BRANCH
        })
      });
      if (createRes.ok) {
        console.log(`[分布式锁] 获取锁成功: ${lockName}`);
        return true;
      }
      console.log(`[分布式锁] 获取锁失败（创建冲突）: ${lockName}`);
      return false;
    }
    
    if (!res.ok) {
      console.error(`[分布式锁] 读取锁文件失败: ${res.status}`);
      return false;
    }
    
    const json = await res.json();
    const lockData = JSON.parse(Buffer.from(json.content, 'base64').toString('utf8'));
    
    // 2. 检查锁是否已过期
    const lockedAt = new Date(lockData.lockedAt).getTime();
    const isExpired = (now - lockedAt) > (lockData.ttl * 1000);
    
    if (!lockData.locked || isExpired) {
      // 锁未持有或已过期，获取锁
      const newLockData = {
        locked: true,
        lockedAt: new Date(now).toISOString(),
        instanceId: process.env.RAILWAY_REPLICA_ID || process.pid || 'unknown',
        ttl: ttlSeconds
      };
      const content = Buffer.from(JSON.stringify(newLockData, null, 2)).toString('base64');
      const updateRes = await fetch(`https://api.github.com/repos/${GITHUB_REPO}/contents/${lockPath}`, {
        method: 'PUT',
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: 'application/vnd.github.v3+json',
          'Content-Type': 'application/json',
          'User-Agent': 'reading-checkin'
        },
        body: JSON.stringify({
          message: `Acquire lock: ${lockName}`,
          content,
          sha: json.sha,
          branch: GITHUB_DATA_BRANCH
        })
      });
      if (updateRes.ok) {
        console.log(`[分布式锁] 获取锁成功: ${lockName}`);
        return true;
      }
      console.log(`[分布式锁] 获取锁失败（更新冲突）: ${lockName}`);
      return false;
    }
    
    // 3. 锁已被其他实例持有
    console.log(`[分布式锁] 锁已被持有: ${lockName}, instanceId: ${lockData.instanceId}`);
    return false;
    
  } catch (e) {
    console.error(`[分布式锁] 获取锁异常: ${e.message}`);
    return false;
  }
}

// 释放分布式锁
// lockName: 锁名称
// 返回: true=释放成功, false=释放失败
async function releaseDistributedLock(lockName) {
  const lockPath = `_locks/${lockName}.json`;
  const url = `https://api.github.com/repos/${GITHUB_REPO}/contents/${lockPath}?ref=${GITHUB_DATA_BRANCH}`;
  
  try {
    // 1. 读取锁文件（获取SHA）
    const res = await fetch(url, {
      headers: {
        Authorization: `token ${GITHUB_TOKEN}`,
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'reading-checkin'
      }
    });
    
    if (!res.ok) {
      console.log(`[分布式锁] 锁文件不存在或读取失败: ${lockName}`);
      return true; // 锁文件不存在，视为释放成功
    }
    
    const json = await res.json();
    const lockData = JSON.parse(Buffer.from(json.content, 'base64').toString('utf8'));
    
    // 2. 检查是否是自己持有的锁
    const currentInstanceId = process.env.RAILWAY_REPLICA_ID || process.pid || 'unknown';
    if (lockData.instanceId !== currentInstanceId) {
      console.log(`[分布式锁] 锁不是自己持有的，不释放: ${lockName}, owner: ${lockData.instanceId}`);
      return false;
    }
    
    // 3. 释放锁（标记为未锁定）
    const newLockData = {
      ...lockData,
      locked: false,
      releasedAt: new Date().toISOString()
    };
    const content = Buffer.from(JSON.stringify(newLockData, null, 2)).toString('base64');
    const updateRes = await fetch(`https://api.github.com/repos/${GITHUB_REPO}/contents/${lockPath}`, {
      method: 'PUT',
      headers: {
        Authorization: `token ${GITHUB_TOKEN}`,
        Accept: 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
        'User-Agent': 'reading-checkin'
      },
      body: JSON.stringify({
        message: `Release lock: ${lockName}`,
        content,
        sha: json.sha,
        branch: GITHUB_DATA_BRANCH
      })
    });
    
    if (updateRes.ok) {
      console.log(`[分布式锁] 释放锁成功: ${lockName}`);
      return true;
    }
    
    console.error(`[分布式锁] 释放锁失败: ${updateRes.status}`);
    return false;
    
  } catch (e) {
    console.error(`[分布式锁] 释放锁异常: ${e.message}`);
    return false;
  }
}


// ========= 持久化日志（写入主数据库，不丢失） =========
// 日志存储在 _logs 数组，最多保留100条
// =============================================================

async function addLog(task, status, detail) {
  for (let retry = 0; retry < 3; retry++) {
    try {
      const fresh = await readFresh();
      if (!fresh || !fresh.data) return;
      
      if (!fresh.data._logs) fresh.data._logs = [];
      
      const now = new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });
      fresh.data._logs.unshift({
        time: now,
        task: task,
        status: status,
        detail: detail
      });
      
      // 只保留最近100条
      if (fresh.data._logs.length > 100) {
        fresh.data._logs = fresh.data._logs.slice(0, 100);
      }
      
      await writeWithData(fresh.data, fresh.sha);
      return;
    } catch (e) {
      if (e.message && e.message.includes('SHA')) {
        await new Promise(r => setTimeout(r, 500));
        continue;
      }
      console.error('[db] addLog failed:', e.message);
      return;
    }
  }
}

module.exports = { read, readFresh, write, writeAndWait, writeWithData, updateCache, tryAcquireCronLock, acquireDistributedLock, releaseDistributedLock, addLog };
